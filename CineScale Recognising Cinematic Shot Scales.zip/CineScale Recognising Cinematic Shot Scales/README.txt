
# Shot scale dataset

## Structure

The manual annotations can be found, with a dual structure with respect to the frames, in path `annotations/`. For each movie there is a single `.csv` file.

All the frames can be asked to the authors or from the official project page: https://cinescale.github.io/

## Mappings
In the annotation files the `shotscale` column has this code mapping:

`
0	FS    	Foreground shot
1	ECU		Extreme close up	
2	CU		Close up
3	MCU		Medium close up
4	MS 		Medium shot
5	MLS 	Medium long shot
6	LS 		Long shot
7	ELS 	Extreme long shot
8	INS 	Insert
9   NA 		Not available 
`

# Changelog
All notable changes to this project will be documented in this file.

## v1 - 2020-10-26
Initial upload